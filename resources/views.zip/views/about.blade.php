@extends('layouts.app')

@section('content')
    <div class="text-center">
        <h1>About page</h1>
        <h2>Text</h2>
    </div>
@endsection