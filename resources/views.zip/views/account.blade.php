@extends('layouts.app')

@section('content')
    @include('layouts.sidebar')
@endsection