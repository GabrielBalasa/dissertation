@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row m-5">
            <h1>Contact us.</h1>
        </div>
    </div>
@endsection