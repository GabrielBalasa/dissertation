@extends('layouts.app')

@section('content')
    <div class="container-fluid d-flex flex-row h-100" >
        @include('trainer.sidemenu')
        <div class="d-flex flex-column m-5">
            <h1>Clients</h1>
            <ul>
                @foreach($subscribers as $subscriber)
                    <li>{{$subscriber->user->email}}</li>
                @endforeach
            </ul>
        </div>
    </div>
@endsection