@extends('layouts.app')

@section('content')
    <div class="container-fluid d-flex flex-row h-100" >
        @include('trainer.sidemenu')
        <div class="d-flex flex-column m-5">
            @include('partials.formerrors')
            <h1>Dashboard</h1>
            <a class="btn primary-btn text-light w-75" href="/trainer/settiers" role="button">
                Set Tiers
            </a>
        </div>
    </div>
@endsection