@extends('layouts.app')

@section('content')
    <div class="container-fluid d-flex flex-row h-100" >
        @include('trainer.sidemenu')
        <div class="d-flex flex-column w-75 m-5">
            <div class="row">
                <div class="col-8">
                    <h1>Exercises</h1>
                </div>
                <div class="col-4 align-self-center">
                    <a class="btn primary-btn text-light" href="/trainer/exercises/newexercise" role="button">
                        New exercise
                    </a>
                </div>
            </div>
            @include('partials.success')
            <div class="row">
                @if($exercises)
                    @foreach($exercises as $exercise)
                        <li>{{$exercise->exercise_title}}
                            <a class="btn primary-btn text-light" href="/trainer/exercises/{{$exercise->exercise_id}}/assign" role="button">
                                Assign
                            </a>
                            <a class="btn primary-btn text-light" href="/trainer/exercises/{{$exercise->exercise_id}}" role="button">
                                Edit
                            </a>
                            <a class="btn primary-btn text-light" href="/trainer/exercises/{{$exercise->exercise_id}}/delete" role="button">
                                Delete
                            </a>
                            
                        </li>
                    @endforeach
                @else
                    <h3>You don't have any exercises yet.</h3>
                @endif
            </div>
        </div>
    </div>
@endsection