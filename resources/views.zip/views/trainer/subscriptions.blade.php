@extends('layouts.app')

@section('content')
    <div class="container-fluid d-flex flex-row h-100" >
        @include('trainer.sidemenu')
        <div class="d-flex flex-column m-5">
            Tier 1: {{$subscriptions['tier1_price'] }} - {{ $subscriptions['tier1_description']}}
            Tier 2: {{$subscriptions['tier2_price'] }} - {{ $subscriptions['tier2_description']}}
            Tier 3: {{$subscriptions['tier3_price'] }} - {{ $subscriptions['tier3_description']}}
        </div>
    </div>
@endsection