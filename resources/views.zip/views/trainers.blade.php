@extends('layouts.app')

@section('content')
    <div class="container-fluid m-5 p-5">
    @foreach($trainersList as $row)
        <div>{{$row['email']}}</div>
    @endforeach
    </div>
@endsection

{{-- <div class="container-fluid m-5 p-5">
    <h1>List of trainers</h1>
        <div class="row">
            <div class="col-md-8">
                <table class="table table-bordered">
                    <tr>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                    @foreach($trainersList as $row)
                        <tr>
                            <td>{{$row['trainer_firstname']}}</td>
                            <td>{{$row['trainer_lastname']}}</td>
                            <td></td>
                            <td></td>
                        </tr>
                    @endforeach
                </table>
            </div>
        </div>
    </div> --}}