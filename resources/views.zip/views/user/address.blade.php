@extends('layouts.app')

@section('content')
    <div class="container-fluid d-flex flex-row h-100" >
        @include('user.sidemenu')
        <div class="d-flex flex-column m-5">
            <form method="POST" action="/user/personaldetails/changeaddress">
                @include('partials.success')
                {{ csrf_field() }}
                <div class="col-11">
                    <label for="address">Address:</label>
                    <input type="text" class="form-control" id="address" name="address" value="{{$user['address']}}">
                </div>
                
                <div class="col-11">
                    <label for="city">City:</label>
                    <input type="text" class="form-control" id="city" name="city" value="{{$user['city']}}">
                </div>
        
                <div class="col-11 pt-2">
                    <label for="postcode">Postcode:</label>
                    <input type="postcode" class="form-control" id="postcode" name="postcode" value="{{$user['postcode']}}">
                </div>
        
                <div class="col-12 pt-3">
                    <button style="cursor:pointer" type="submit" class="btn btn-primary">Submit</button>
                </div>
                @include('partials.formerrors')
            </form>
        </div>
    </div>
@endsection 