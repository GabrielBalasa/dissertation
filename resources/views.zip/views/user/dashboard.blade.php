@extends('layouts.app')

@section('content')
    <div class="container-fluid d-flex flex-row h-100" >
        @include('user.sidemenu')
        <div class="d-flex flex-column m-5">
            @include('partials.formerrors')
            <h1>Dashboard</h1>
        </div>
    </div>
@endsection