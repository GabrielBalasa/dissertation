@extends('layouts.app')

@section('content')
    <div class="container-fluid d-flex flex-row h-100" >
        @include('user.sidemenu')
        <div class="d-flex flex-column m-5">
            <ul>
                @foreach ($workouts as $workout)
                    {{$workout->workout->workout_title}}
                    {{$workout->workout_start_date}}
                    {{$workout->workout_end_date}}
                    <a class="btn primary-btn text-light" href="/user/exercises/{{$workout->workout_id}}" role="button">
                        View
                    </a>
                @endforeach
            </ul>
        </div>
    </div>
@endsection