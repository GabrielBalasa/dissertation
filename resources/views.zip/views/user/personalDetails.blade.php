@extends('layouts.app')

@section('content')
    <div class="container-fluid d-flex flex-row h-100" >
        @include('user.sidemenu')
        <div class="d-flex flex-column m-5">
            <h1>Personal Details</h1>
            <div>
                <div>
                    <div class="d-flex align-self-center m-2">
                        <a class="btn primary-btn text-light w-75" href="/user/personaldetails/changeaddress" role="button">
                                Change address
                        </a>
                    </div>
                    <div class="d-flex align-self-center m-2">
                        <a class="btn primary-btn text-light w-75" href="/user/personaldetails/changepassword" role="button">
                                Change password
                        </a>
                    </div>
                </div>
            
                <form method="POST" action="/user/personaldetails">
                    @include('partials.formerrors')
                    @include('partials.success')
                    {{ csrf_field() }}
                    <div class="col-11">
                        <label for="firstname">First name:</label>
                        <input type="text" class="form-control" id="firstname" name="firstname" value="{{$user['firstname']}}">
                    </div>
                    
                    <div class="col-11">
                        <label for="lastname">Last name:</label>
                        <input type="text" class="form-control" id="lastname" name="lastname" value="{{$user['lastname']}}">
                    </div>
            
                    <div class="col-11 pt-2">
                        <label for="email">Email:</label>
                        <input type="email" class="form-control" id="email" name="email" value="{{$user['email']}}">
                    </div>
            
                    <div class="col-12 pt-3">
                        <button style="cursor:pointer" type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection