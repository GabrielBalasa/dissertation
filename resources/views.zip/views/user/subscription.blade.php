@extends('layouts.app')

@section('content')
    <div class="container-fluid d-flex flex-row h-100" >
        @include('user.sidemenu')
        <div class="d-flex flex-column m-5">
            {{$subscription["tier{$subscriber->subscription_tier}_price"]}}£ -
            {{$subscription["tier{$subscriber->subscription_tier}_description"]}}
        </div>
    </div>
@endsection